
import java.io.File

import org.apache.log4j.{Level, LogManager, Logger}
import org.apache.spark.SparkConf
import org.apache.spark.SparkContext
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.SQLContext


object tasks
{
  protected val logger: Logger = {
    val l = LogManager.getRootLogger
    l.setLevel(Level.DEBUG)

    val org = LogManager.getLogger("org")
    org.setLevel(Level.OFF)

    l
  }
  val conf = new.SparkConf()
    .setAppName("RDDDF project")
    .setMaster("local")
  val sc = new SparkContext(conf)

  //val sqlContext = new SQLContext(sc)
  val dfcsv = sqlContext.read
    .format("com.databricks.spark.csv")
    .option("header", "true") // Use first line of all files as header
    .option("inferSchema", "true") // Automatically infer data types
    .load("src\\main\\resources\\SacramentocrimeJanuary2006.csv")

  val sqlContext = new org.apache.spark.sql.SQLContext(sc)

  val dftsv = sqlContext.read
    .format("com.databricks.spark.csv")
    .option("header", "true") // Use first line of all files as header
    .option("inferSchema", "true") // Automatically infer data types
    .option("delimeter", "\\t")
    .load("src\\main\\resources\\SacramentocrimeJanuary2006.csv")


  val rddcsv = dfcsv.rdd
  val rddtsv = dftsv.rdd

  )





}